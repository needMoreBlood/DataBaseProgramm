﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SQLite;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;

namespace TestBaseCreate
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int Time = 5; // время таймера, секунды

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }
        
        void GO()
        {
            string from;
            string to;
            DateTime SelectedStartDate = SelectMax();
            DateTime SelectedDate = SelectedStartDate;
            DateTime NowDate = DateTime.Now;
            while (DateTime.Parse(SelectedDate.ToString()).ToString("yyyy-MM-dd") != DateTime.Parse(NowDate.ToString()).ToString("yyyy-MM-dd"))
            {
                from = @"\\DESKTOP-OI3POC0\M_DB\" + DateTime.Parse(SelectedDate.ToString()).ToString("M.yyyy") + @"\" + DateTime.Parse(SelectedDate.ToString()).ToString("d.M.yyyy") + ".db"; //откуда копируем
                to = Application.StartupPath + @"\ForCopy\ForCopy.db";
                try
                {
                File.Copy(from, to, true);
                SelectedDate = SelectedDate.AddDays(1);
                sql(to, SelectedStartDate);
                richTextBox1.Text += "База данных " + DateTime.Parse(SelectedDate.ToString()).ToString("M.yyyy") + @"\" + DateTime.Parse(SelectedDate.ToString()).ToString("d.M.yyyy") + ".db" + " скопирована;" + "\n";
                }
                catch
                {
                    richTextBox1.Text += "База оборудования не доступна " + DateTime.Now + ";" + "\n";
                    break;
                }
            }
            from = @"\\DESKTOP-OI3POC0\M_DB\" + DateTime.Parse(NowDate.ToString()).ToString("M.yyyy") + @"\" + DateTime.Parse(NowDate.ToString()).ToString("d.M.yyyy") + ".db"; //откуда копируем
            to = Application.StartupPath + @"\ForCopy\ForCopy.db";
            try
            {
                File.Copy(from, to, true);
                richTextBox1.Text += "База данных " + DateTime.Parse(NowDate.ToString()).ToString("M.yyyy") + @"\" + DateTime.Parse(NowDate.ToString()).ToString("d.M.yyyy") + ".db" + " скопирована;" + "\n";
                sql(to, SelectedStartDate);
                richTextBox1.Text += "База успешно обновлена в: " + DateTime.Now + ";" + "\n";
                richTextBox1.Text += "\n";
            }
            catch
            {
                richTextBox1.Text += "База оборудования не доступна " + DateTime.Now + ";" + "\n";
            }
        }

        DateTime SelectMax()
        {
            DataTable dTableSelectedMax = new DataTable();
            string BasePath = Application.StartupPath + @"/TEST3000.db"; // откуда проверяем
            string commandText = "SELECT MAX(TIMESTAMP) FROM TEST1";
            if (!File.Exists(BasePath))
            {
                richTextBox1.Text += "Не удалось открыть базу сервера по указанному пути;" + "\n";
            }
            if (File.Exists(BasePath))
            {
               SQLiteConnection connect = new SQLiteConnection();
               connect = new SQLiteConnection(@"Data Source=" + BasePath + ";" + "Version =3; ReadOnly=true;");
               SQLiteCommand sqlCommand = connect.CreateCommand();
               connect.Open();
               richTextBox1.Text += "Серверная база открыта;" + "\n";
               SQLiteDataAdapter adapterTestServer = new SQLiteDataAdapter(commandText, connect);
               adapterTestServer.Fill(dTableSelectedMax);
               connect.Close();
               richTextBox1.Text += "Последняя запись серверной базы от: " + dTableSelectedMax.Rows[0][0] + ";" + "\n";
            }
            return Convert.ToDateTime(dTableSelectedMax.Rows[0][0]);
        }
        void sql(string BasePath, DateTime SelectedDate)
        {
            DataTable dTableTest = new DataTable();
            if (File.Exists(BasePath))
            {
                SQLiteConnection connect = new SQLiteConnection();
                connect = new SQLiteConnection(@"Data Source=" + BasePath + ";" + "Version =3; ReadOnly=false;");
                SQLiteCommand sqlCommand = new SQLiteCommand();
                if (connect.State != ConnectionState.Open)
                {
                    connect.Open();
                    sqlCommand.Connection = connect;
                }
                try
                {
                       sqlCommand.CommandText = "CREATE TABLE IF NOT EXISTS " + "NEWTEST " +  "(" + "id INTEGER, TIMESTAMP TEXT, OPERATOR BLOB, NAME BLOB, H INTEGER, VSHAKE REAL, " +
                            "SHAKE INTEGER, MAINCOUNTER INTEGER, RESERVE REAL, RESULT INTEGER, TEMPERATURE REAL, CRANK_R INTEGER, SPEEDCOUNT INTEGER, V1 REAL, V2 REAL, V3 REAL, V4 REAL," +
                            "V5 REAL, V6 REAL, V7 REAL, V8 REAL, V9 REAL, V10 REAL, V11 REAL, V12 REAL, V13 REAL, V14 REAL, V15 REAL, V16 REAL, V17 REAL, V18 REAL, V19 REAL, V20 REAL,	PRIMARY KEY(id));"+
                        "INSERT INTO NEWTEST SELECT *FROM TEST;" +
                       "DROP TABLE TEST;" +
                        "ALTER TABLE NEWTEST RENAME TO TEST;";
                        sqlCommand.ExecuteNonQuery();
                        richTextBox1.Text += "Формат ключевых строк скопированной базы успешно исправлен;" + "\n";
                }
                catch (SQLiteException ex)
                {
                    richTextBox1.Text += "Ошибка в исправлении формата скопированной базы данных;" + "\n";
                }
                string commandText = "SELECT TIMESTAMP, OPERATOR, NAME, MAINCOUNTER, RESULT FROM TEST";
                SQLiteDataAdapter adapterTestServer = new SQLiteDataAdapter(commandText, connect);
                adapterTestServer.Fill(dTableTest);
                connect.Close();
            }

            string ServerBasePath = Application.StartupPath + @"/TEST3000.db"; //куда пишем
            if (File.Exists(ServerBasePath))
            {
                SQLiteConnection connect = new SQLiteConnection();
                connect = new SQLiteConnection(@"Data Source=" + ServerBasePath + ";" + "Version =3; ReadOnly=false;");
                SQLiteCommand sqlCommand = new SQLiteCommand();

                if (connect.State != ConnectionState.Open)
                {
                    connect.Open();
                    sqlCommand.Connection = connect;
                }
                try
                {
                    int strok = 0;
                    string NAME;
                    string OPERATOR;
                    for (int i = 0; i < dTableTest.Rows.Count; i++)
                    {
                        if (Convert.ToDateTime(dTableTest.Rows[i][0]) > SelectedDate)
                        {
                            strok = strok + 1;
                            try
                            {
                                byte[] ByteName = (byte[])dTableTest.Rows[i][2];
                                NAME = Encoding.GetEncoding(1251).GetString(ByteName);
                                byte[] ByteOperator = (byte[])dTableTest.Rows[i][1];
                                OPERATOR = Encoding.GetEncoding(1251).GetString(ByteOperator);
                            }
                            catch
                            {
                                NAME = dTableTest.Rows[i][2].ToString();
                                OPERATOR = dTableTest.Rows[i][1].ToString();
                            }
                            sqlCommand.CommandText = "INSERT INTO 'TEST1' (TIMESTAMP, OPERATOR, NAME, MAINCOUNTER, RESULT) VALUES('"
                            + DateTime.Parse(dTableTest.Rows[i][0].ToString()).ToString("yyyy-MM-dd HH:mm:ss") + "','" + OPERATOR + "','" + NAME + "','" + dTableTest.Rows[i][3]
                            + "','" + dTableTest.Rows[i][4] + "')" + "\n";
                            sqlCommand.ExecuteNonQuery();
                        }
                    }
                    richTextBox1.Text += "Найдено новых строк: " + strok + ";" + "\n";
                }
                catch (SQLiteException ex)
                {

                }
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Time = Time - 1;
            label1.Text = Time.ToString() + " Сек";
            if (Time == 0)
            {
                GO();
                Time = 30;
            }
        }
    }
}
